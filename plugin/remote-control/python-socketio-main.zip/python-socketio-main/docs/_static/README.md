Place static files used by the documentation here.
