
# Socket.IO Fiddle

```
$ npm install
$ node fiddle-client.js   # to run the fiddle example
$ node latency-client.js  # to run the latency example
```

Optionally, specify a port by supplying the `PORT` env variable.
