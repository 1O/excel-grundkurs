Socket.IO Examples
==================

This directory contains several example Socket.IO applications. Look in the
`server` directory for Socket.IO servers, and in the `client` directory for
Socket.IO clients.