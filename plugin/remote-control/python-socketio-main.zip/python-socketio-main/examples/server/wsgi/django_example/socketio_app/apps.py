from django.apps import AppConfig


class SocketioAppConfig(AppConfig):
    name = 'socketio_app'
