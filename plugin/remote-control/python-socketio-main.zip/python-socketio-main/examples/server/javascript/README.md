
# Socket.IO JavaScript Examples

```
$ npm install
$ node fiddle  # to run the fiddle server example
$ node latency # to run the latency server example
```

And point your browser to `http://localhost:5000`. Optionally, specify
a port by supplying the `PORT` env variable.
